/* Henry Yang, Period 3, 3/30/14
 * Around 4 hours.
 * Unfortunately, my program isn't working. The issue is that my recursive
 * reveal method does not work like it should 100% of the time. Sometimes, it
 * will reveal a straight diagonal line of blank cells, but nothing around 
 * them. I'm still in the process of figuring out why that is happening. Also,
 * I can't seem to figure out why nothing happens when I click on a mine. The
 * line that handles that case is very straightforward, so it must be a bug 
 * elsewhere. Other than that, my program is good with changing number of mines,
 * displaying about/help pages, and recursively revealing empty spots for the 
 * most part.
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.net.URL;
import javax.imageio.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
public class Minesweeper extends MouseAdapter implements ActionListener{
    int[][] bombGrid = new int[20][20];
    int[][] displayGrid = new int[20][20];
    
    
    
    JFrame window = new JFrame("MINESWEEPER");
    MyJPanel playingGrid = new MyJPanel();
    
    JLabel bombsRemaining;
    JLabel timeSpent;
    
    int numBombs = 40;
    int timeElapsed = 0;
    int gridSize = 20;
    
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    
    BufferedImage blankMine;
    BufferedImage noMine;
    BufferedImage yesMine;
    BufferedImage flag;
    
    boolean gameStarted = false;
    javax.swing.Timer timer;
    
    public static void main(String[] args){
        Minesweeper test = new Minesweeper();
        test.createGUI();
    }
    
    public void createGUI(){
        //create jframe
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false);
        
        int screenWidth = (int)(window.getToolkit().getScreenSize().getWidth());
        int screenHeight = (int)(window.getToolkit().getScreenSize().getHeight());
        
        int frameWidth = 442;
        int frameHeight = 600;
        
        window.setBounds(screenWidth/2 - frameWidth/2, screenHeight/2 - frameHeight/2, frameWidth, frameHeight);
        window.setLayout(null);
        
        //add playing grid
        window.add(playingGrid);
        
        playingGrid.setBounds(20,20,402,402);
        playingGrid.setBackground(Color.white);
        playingGrid.addMouseListener(this);
        
        try{
            blankMine = ImageIO.read(new File("unclicked.png"));
        }catch(Exception e){
            e.printStackTrace();
        }
        
        try{
            noMine = ImageIO.read(new File("clicked_blank.png"));
        }catch(Exception e){
            e.printStackTrace();
        }
        
        try{
            yesMine = ImageIO.read(new File("mine.png"));
        }catch(Exception e){
            e.printStackTrace();
        }
        
        try{
            flag = ImageIO.read(new File("flag.png"));
        }catch(Exception e){
            e.printStackTrace();
        }
        
        
        //add bombs left
        bombsRemaining = new JLabel(numBombs + "");
        bombsRemaining.setBorder(new TitledBorder("Bombs Left"));
        window.add(bombsRemaining);
        int bombLabelWidth = 120;
        int bombLabelHeight = 80;
        bombsRemaining.setBounds(221, 422, bombLabelWidth, bombLabelHeight);
        
        
        //add time elapsed
        timeSpent = new JLabel(timeElapsed + "");
        timeSpent.setBorder(new TitledBorder("Time Elapsed"));
        window.add(timeSpent);
        int timeLabelWidth = 120;
        int timeLabelHeight = 80;
        timeSpent.setBounds(221-timeLabelWidth , 422, timeLabelWidth, timeLabelHeight);
        
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        
        jMenu1.setText("Game");

        jMenuItem1.setText("New Game");
        
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Exit");
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Options");

        jMenuItem3.setText("Total Mines");
        jMenuItem3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                try{
                    JOptionPane setMines = new JOptionPane();
                    String prompt = "Enter the number of bombs you want. \nThe game will restart with " +
                                    "the new amount of bombs.";
                    String newBombs = setMines.showInputDialog(null, prompt, "Set Bombs", JOptionPane.PLAIN_MESSAGE);
                    try{
                        numBombs = Integer.parseInt(newBombs);
                        bombsRemaining.setText(numBombs + "");
                    }catch(Exception ex){
                        ex.printStackTrace();
                        System.out.println("Enter a number without spaces!");
                    }
                }catch(Exception ex){
                    ex.printStackTrace();
                }
                
            }
        });
        jMenu2.add(jMenuItem3);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Help");

        jMenuItem4.setText("How to Play");
        jMenuItem4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                try{
                    JTextPane howTo = new JTextPane();
                    howTo.setPage(new URL("file:minesweeper_howtoplay.html"));
                    howTo.setEditable(false);
                    JScrollPane helpScroll = new JScrollPane(howTo);
                    helpScroll.setPreferredSize(new Dimension(400,400));
                    JOptionPane display = new JOptionPane(helpScroll);
                    display.showMessageDialog(null, helpScroll, "How To Play", JOptionPane.PLAIN_MESSAGE);
                }catch(Exception ex){
                    ex.printStackTrace();
                }
                
            }
        });
        
        jMenu3.add(jMenuItem4);
        

        jMenuItem5.setText("About");
        jMenuItem5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                try{
                    JTextPane about = new JTextPane();
                    about.setPage(new URL("file:minesweeper_about.html"));
                    about.setEditable(false);
                    JOptionPane display = new JOptionPane(about);
                    display.showMessageDialog(null, about, "About", JOptionPane.PLAIN_MESSAGE);
                }catch(Exception ex){
                    ex.printStackTrace();
                }
                
            }
        });
        
        
        jMenu3.add(jMenuItem5);

        jMenuBar1.add(jMenu3);

        window.setJMenuBar(jMenuBar1);
        
        
        
        
        
        
        window.setVisible(true);
        initializeGame();
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == timer){
            timeElapsed++;
            timeSpent.setText(timeElapsed + "");
        }
    }
    
    
    public void initializeGame(){
        bombGrid = newBoard(gridSize, numBombs);
        for(int r = 0; r<gridSize; r++){
            for(int c = 0; c<gridSize; c++){
                displayGrid[r][c] = -1;
            }
        }
        
        
    }
    
    public void mouseClicked(MouseEvent e){
        if(e.getButton() == MouseEvent.BUTTON1){
            if(gameStarted == false){
                gameStarted = true;
                timer.start();
            }
            
            
            int xPos = e.getX()/gridSize;
            int yPos = e.getY()/gridSize;
            reveal(yPos, xPos, displayGrid);
            playingGrid.repaint();
        }
        
        else if(e.getButton() == MouseEvent.BUTTON3){
            int xPos = e.getX()/gridSize;
            int yPos = e.getY()/gridSize;
            displayGrid[yPos][xPos] = 9;
            playingGrid.repaint();
        }
        
    }
    
    public void reveal(int row, int col, int[][] board){
        /*
        int[][] tempBoard = new int[board.length][board[0].length];
        for(int r = 0; r<board.length; r++){
            for(int c = 0; c<board[0].length; c++){
                tempBoard = board[r][c];
            }
        }
        */
        if(bombGrid[row][col] == 10){
            timer.stop();
            board[row][col] = 10;
            JOptionPane gameOver = new JOptionPane();
            gameOver.showMessageDialog(null, "Game Over", "Game Over", JOptionPane.PLAIN_MESSAGE);
            initializeGame();
        }
        else if(board[row][col] == -1){
            if(neighbors(row,col,bombGrid) == 0){
                //go into recursion
                board[row][col] = 0;
                reveal(row-1, col-1, board);
                reveal(row-1, col, board);
                reveal(row-1, col+1, board);
                reveal(row, col-1, board);
                reveal(row, col+1, board);
                reveal(row+1, col-1, board);
                reveal(row+1, col, board);
                reveal(row+1, col-1, board);
            }
            else{
                board[row][col] = neighbors(row,col,bombGrid);
                System.out.println(neighbors(row,col,bombGrid) + "");
            }
        }
        
    }
    
    public int neighbors(int row, int col, int[][] board){
        int result = 0;
        if(isInBounds(row-1, col-1, board)){
            if(board[row-1][col-1] == 10){
                result++;
            }
        }
        
        if(isInBounds(row-1, col, board)){
            if(board[row-1][col] == 10){
                result++;
            }
        }
        
        if(isInBounds(row-1, col+1, board)){
            if(board[row-1][col+1] == 10){
                result++;
            }
        }
        
        if(isInBounds(row, col-1, board)){
            if(board[row][col-1] == 10){
                result++;
            }
        }
        
        if(isInBounds(row, col+1, board)){
            if(board[row][col+1] == 10){
                result++;
            }
        }
        
        if(isInBounds(row+1, col-1, board)){
            if(board[row+1][col-1] == 10){
                result++;
            }
        }
        
        if(isInBounds(row+1, col, board)){
            if(board[row+1][col] == 10){
                result++;
            }
        }
        
        if(isInBounds(row+1, col+1, board)){
            if(board[row+1][col+1] == 10){
                result++;
            }
        }
        
        return result;
    }
    
    public boolean isInBounds(int row, int col, int[][] board){
        int numRows = board.length;
        int numCols = board[0].length;
        
        if(row < numRows && col < numCols && row >= 0 && col >= 0){
            return true;
        }
        else{
            return false;
        }
    }
    
    public int[][] newBoard(int size, int numBombs){
        Random ran = new Random();
        int[][] result = new int[size][size];
        int r = 0;
        int c = 0;
        for(int i = 0; i<numBombs; i++){
            r = ran.nextInt(19);
            c = ran.nextInt(19);
            while(result[r][c] == 10){//while there is a mine, try another spot
                r = ran.nextInt(19);
                c = ran.nextInt(19);
            }
            result[r][c] = 10;
        }
        return result;
    }
    
    private class MyJPanel extends JPanel{
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D)g;
            
            int side = getWidth();
            int gridSize = side/20;
            for(int r = 0; r<20; r++){
                for(int c = 0; c<20; c++){
                    //g2.setColor(Color.black);
                    //g2.drawRect(1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize);
                    g2.drawImage(blankMine,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                    
                    if(displayGrid[r][c] == 0){
                        g2.setColor(new Color(58,95,205));
                        g2.drawImage(noMine,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                    }
                    else if(displayGrid[r][c] == 1){
                        g2.setColor(new Color(58,95,205));
                        g2.drawImage(noMine,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                        g2.drawString("1", (int)(1 + (c+.25)*gridSize), (int)(1 + (r+.75)*gridSize));
                    }
                    else if(displayGrid[r][c] == 2){
                        g2.setColor(new Color(219,112,147));
                        g2.drawImage(noMine,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                        g2.drawString("2", (int)(1 + (c+.25)*gridSize), (int)(1 + (r+.75)*gridSize));
                    }
                    else if(displayGrid[r][c] == 3){
                        g2.setColor(new Color(0,128,0));
                        g2.drawImage(noMine,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                        g2.drawString("3", (int)(1 + (c+.25)*gridSize), (int)(1 + (r+.75)*gridSize));
                    }
                    else if(displayGrid[r][c] == 4){
                        g2.setColor(new Color(218,165,32));
                        g2.drawImage(noMine,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                        g2.drawString("4", (int)(1 + (c+.25)*gridSize), (int)(1 + (r+.75)*gridSize));
                    }
                    else if(displayGrid[r][c] == 5){
                        g2.setColor(new Color(139,0,139));
                        g2.drawImage(noMine,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                        g2.drawString("5", (int)(1 + (c+.25)*gridSize), (int)(1 + (r+.75)*gridSize));
                    }
                    else if(displayGrid[r][c] == 6){
                        g2.setColor(new Color(105,139,34));
                        g2.drawImage(noMine,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                        g2.drawString("6", (int)(1 + (c+.25)*gridSize), (int)(1 + (r+.75)*gridSize));
                    }
                    else if(displayGrid[r][c] == 7){ 
                        g2.setColor(new Color(139,58,58));
                        g2.drawImage(noMine,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                        g2.drawString("7", (int)(1 + (c+.25)*gridSize), (int)(1 + (r+.75)*gridSize));
                    }
                    else if(displayGrid[r][c] == 8){ 
                        g2.setColor(Color.white);
                        g2.drawImage(noMine,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                        g2.drawString("8", (int)(1 + (c+.25)*gridSize), (int)(1 + (r+.75)*gridSize));
                    }
                    else if(displayGrid[r][c] == 9){ //flag
                        g2.setColor(Color.blue);
                        g2.drawImage(blankMine,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                        g2.drawImage(flag,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                    }
                    else if(displayGrid[r][c] == 10){ //bomb
                        g2.setColor(Color.blue);
                        g2.drawImage(noMine,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                        g2.drawImage(yesMine,1 + c*gridSize, 1 + r*gridSize, gridSize, gridSize, null, null);
                    }
                }
            }
            
            
            
        }
    }
}